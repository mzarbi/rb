<template>
  <v-container class="fill-height" fluid>
    <v-row align="center" justify="center">
      <v-col cols="12" sm="8" md="6">
        <v-card class="elevation-12" outlined>
          <v-card-title class="headline">
            Source Not Found
          </v-card-title>
          <v-card-text>
            The requested source could not be found. Please check the URL and try again.
          </v-card-text>
          <v-card-actions>
            <v-btn color="primary" @click="goBack">Go Back</v-btn>
            <v-spacer></v-spacer>
            <v-btn color="secondary" to="/">Go to Home</v-btn>
          </v-card-actions>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
  export default {
    name: 'SourceNotFoundPage',
    methods: {
      goBack() {
        this.$router.go(-1); // Go back to the previous page
      },
    },
  };
</script>

<style scoped>
  /* Add any additional styling here */
</style>
