<template>
  <div style="margin:5px;border: 1px solid #ccc;">
    <div v-if="isValidSource" style="padding:10px;">
      <RibbonWrapper ref="ribbonWrapper"
                     :ribbon-structure="ribbonStructure"
                     @button-clicked="buttonClicked"
                     @input-changed="inputChanged"
                     @tab-changed="tabChanged"

      ></RibbonWrapper>
      <v-window v-model="tab">

        <v-window-item value="Builder">
          <QueryBuilder @active-node-changed="activeChanged" ref="qb"></QueryBuilder>
        </v-window-item>

        <v-window-item value="Data">
          <vue-excel-editor ref="excelTable" v-model="jsondata" :showImportExcel="false" readonly	filter-row no-header-edit	>
            <vue-excel-column field="user"   label="User ID"       type="string" autoFillWidth />
            <vue-excel-column field="name"   label="Name"          type="string" width="150px" />
            <vue-excel-column field="phone"  label="Contact"       type="string" width="130px" />
            <vue-excel-column field="gender" label="Gender"        type="select" width="50px" :options="['F','M','U']" />
            <vue-excel-column field="age"    label="Age"           type="number" width="70px" />
            <vue-excel-column field="birth"  label="Date Of Birth" type="date"   width="80px" />
          </vue-excel-editor>
        </v-window-item>

      </v-window>

    </div>
  </div>


</template>

<script>
  import RibbonWrapper from "@/components/RibbonWrapper";
  import VueExcelEditor from "@/components/excel/VueExcelEditor";
  import VueExcelColumn from "@/components/excel/VueExcelColumn";
  import QueryBuilder from "@/components/queryBuilder/QueryBuilder";
  const managedSources = {
    adg: {}
  };

  export default {
    name: "DataPage",
    props: {
      dataSource: {
        required: true
      }
    },
    data() {
      const pageCount = 10;
      return {
        tab: "Builder",
        activeNode: null,
        isValidSource: true,
        showDataInfo: false,
        pageCount: pageCount,
        currentPage: 0,
        currentSheet: 0,
        ribbonStructure: {
          tabs: [
            {
              title: "Builder",
              groups: [
                {
                  title: "Query",
                  toolbars: [
                    {
                      size: "70px",
                      tools: [
                        {
                          icon: "/images/32/refresh.png",
                          type: "button",
                          title: "Reload Query",
                          size: "large"
                        }
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          icon: "/images/32/cleaning.png",
                          type: "button",
                          title: "Clear Query",
                          size: "large"
                        }
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          icon: "/images/32/diskette.png",
                          type: "button",
                          title: "Save Query",
                          size: "large"
                        }
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          icon: "/images/32/play.png",
                          type: "button",
                          title: "Execute Query",
                          size: "large"
                        }
                      ]
                    }
                  ]
                },
                {
                  title: "Groups/Rules",
                  toolbars: [
                    {
                      size: "70px",
                      tools: [
                        {
                          icon: "/images/32/3d-modeling.png",
                          type: "button",
                          title: "New Group",
                          size: "large"
                        }
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          icon: "/images/32/rule.png",
                          type: "button",
                          title: "New Rule",
                          size: "large"
                        }
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          icon: "/images/32/delete.png",
                          type: "button",
                          title: "Delete Node",
                          size: "large"
                        }
                      ]
                    }
                  ]
                },
                {
                  title: "Preview",
                  toolbars: [
                    {
                      tools: [
                        {
                          icon: "/images/32/eye.png",
                          type: "button",
                          title: "Show Preview Panel",
                          size: "small"
                        },
                        {
                          icon: "/images/32/hidden.png",
                          type: "button",
                          title: "Hide Preview Panel",
                          size: "small"
                        }
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          icon: "/images/32/json.png",
                          type: "button",
                          title: "JSON",
                          size: "large"
                        }
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          icon: "/images/32/sql.png",
                          type: "button",
                          title: "SQL Like",
                          size: "large"
                        }
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          icon: "/images/32/copy.png",
                          type: "button",
                          title: "Copy To Clipboard",
                          size: "large"
                        }
                      ]
                    },

                  ]
                },
              ]
            },
            {
              title: "Data",
              groups: [
                {
                  title: "Data",
                  toolbars: [
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "Reload Data",
                          icon: "/images/32/refresh.png",
                          size: "large"
                        },
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "Data Info",
                          icon: "/images/32/info.png",
                          size: "large"
                        },
                      ]
                    }
                  ]
                },
                {
                  title: "Page",
                  toolbars: [
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "Page Info",
                          icon: "/images/32/paper (1).png",
                          size: "large"
                        },
                      ]
                    },
                    {
                      tools: [
                        {
                          type: "input",
                          title: "Page",
                          icon: "/images/16/check-mark.png",
                          options: this.generateRangeOptions(0, pageCount)
                        },
                        {
                          type: "button",
                          title: "Previous Page",
                          icon: "/images/16/chevron-left-custom.png",
                          size: "small"
                        },
                        {
                          type: "button",
                          title: "Next Page",
                          icon: "/images/16/chevron-right-custom.png",
                          size: "small"
                        },
                        // More tools...
                      ]
                    },
                  ]
                },
                {
                  title: "Columns",
                  toolbars: [
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "Column Info",
                          icon: "/images/32/spreadsheet.png",
                          size: "large"
                        },
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "Show All Columns",
                          icon: "/images/32/eye.png",
                          size: "large"
                        },
                      ]
                    },
                    {
                      tools: [
                        {
                          type: "button",
                          title: "Hide Irrelevant",
                          icon: "/images/32/hidden.png",
                          size: "small"
                        },
                        {
                          type: "button",
                          title: "Hide Empty",
                          icon: "/images/32/empty-folder.png",
                          size: "small"
                        },
                        // More tools...
                      ]
                    },
                  ]
                },
                {
                  title: "Filters",
                  toolbars: [
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "Clear Filters",
                          icon: "/images/32/clear-filter.png",
                          size: "large"
                        },
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "Clear Selection",
                          icon: "/images/32/clear-filter.png",
                          size: "large"
                        },
                      ]
                    },

                  ]
                },
                {
                  title: "Export",
                  toolbars: [
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "CSV",
                          icon: "/images/32/csv.png",
                          size: "large"
                        },
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "XLSX",
                          icon: "/images/32/xlsx.png",
                          size: "large"
                        },
                      ]
                    },
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "Parquet",
                          icon: "/images/32/parquet.png",
                          size: "large"
                        },
                      ]
                    },
                    {
                      tools: [
                        {
                          type: "checkbox",
                          title: "Current Page",
                          icon: "/images/16/check-mark.png",
                        },
                        {
                          type: "checkbox",
                          title: "Selected Only",
                          icon: "/images/16/check-mark.png",
                        },
                        {
                          type: "checkbox",
                          title: "All",
                          icon: "/images/16/check-mark.png",
                        },
                      ]
                    },
                  ]
                },
              ]
            },
            {
              title: "Export",
              groups: [
                {
                  title: "Selection",
                  toolbars: [
                    {
                      tools: [
                        {
                          icon: "/images/32/refresh.png",
                          type: "button",
                          title: "Export Selection",
                          size: "small"
                        },
                        {
                          icon: "/images/32/refresh.png",
                          type: "button",
                          title: "Current Batch",
                          size: "small"
                        }
                      ]
                    }
                  ]
                },
                {
                  title: "Export",
                  toolbars: [
                    {
                      tools: [
                        {
                          icon: "/images/32/refresh.png",
                          type: "button",
                          title: "CSV",
                          size: "large"
                        }
                      ]
                    },
                    {
                      tools: [

                        {
                          icon: "/images/32/refresh.png",
                          type: "button",
                          title: "XLSX",
                          size: "large"
                        }
                      ]
                    },
                    {
                      tools: [
                        {
                          icon: "/images/32/refresh.png",
                          type: "button",
                          title: "Parquet",
                          size: "large"
                        }
                      ]
                    }
                  ]
                },
              ]
            }
          ]
        },
        jsondata: [
          {user: 'hc', name: 'Harry Cole',    phone: '1-415-2345678', gender: 'M', age: 25, birth: '1997-07-01'},
          {user: 'sm', name: 'Simon Minolta', phone: '1-123-7675682', gender: 'M', age: 20, birth: '1999-11-12'},
          {user: 'ra', name: 'Raymond Atom',  phone: '1-456-9981212', gender: 'M', age: 19, birth: '2000-06-11'},
          {user: 'ag', name: 'Mary George',   phone: '1-556-1245684', gender: 'F', age: 22, birth: '2002-08-01'},
          {user: 'kl', name: 'Kenny Linus',   phone: '1-891-2345685', gender: 'M', age: 29, birth: '1990-09-01'}
        ]
      };
    },
    watch:{
      activeNode(nv){

      }
    },
    mounted() {
      this.$refs.ribbonWrapper.setSelectValue('Page', this.currentPage.toString())
    },
    methods: {
      activeChanged(node){
        this.activeNode = node;
      },
      tabChanged(title){
        this.tab = title;
      },
      generateRangeOptions(start, end) {
        let options = [];
        for (let i = start; i <= end; i++) {
          options.push({ value: i.toString(), text: `Page ${i}` });
        }
        return options;
      },
      buttonClicked(event,title) {
        const tree = $("#tree").fancytree("getTree");
        switch (title) {
          case 'Reload Data':
            this.handleReloadData(event);
            break;
          case 'Clear Selection':
            this.handleClearSelection();
            break;

          case 'Data Info':
            this.handleDataInfo();
            break;
          case 'Page Info':
            this.handlePageInfo();
            break;
          case 'Previous Page':
            this.handlePreviousPage();
            break;
          case 'Next Page':
            this.handleNextPage();
            break;
          case 'Sheet Info':
            this.handleSheetInfo();
            break;
          case 'Previous Sheet':
            this.handlePreviousSheet();
            break;
          case 'Next Sheet':
            this.handleNextSheet();
            break;
          case 'Column Info':
            this.handleColumnInfo();
            break;
          case 'Show All Columns':
            this.handleShowAllColumns();
            break;
          case 'Hide Irrelevant':
            this.handleHideIrrelevant();
            break;
          case 'Hide Empty':
            this.handleHideEmpty();
            break;
          case 'Clear Filters':
            this.handleClearFilters();
            break;
          case 'CSV':
            this.handleExportCSV();
            break;
          case 'XLSX':
            this.handleExportXLSX();
            break;
          case 'Parquet':
            this.handleExportParquet();
            break;
          case 'Export Selection':
            this.handleExportSelection();
            break;
          case 'Current Batch':
            this.handleCurrentBatch();
            break;
          case 'Save Query':
            this.$refs.qb.saveTreeData()
            break;
          case 'Reload Query':
            this.$refs.qb.reloadTreeData()
            break;
          case 'Clear Query':
            this.$refs.qb.setTreeData([{
              title: "", key: "0", folder: true, groupType: "AND"}])
            break;
          case 'Delete Node':
            this.activeNode.remove();
            break;
          case 'New Group':
            var node = tree.getNodeByKey(this.activeNode.key);
            if (node){
              node.addChildren({ title: "", folder: true, groupType: "AND"});
            }else{
              var rootNode = tree.getRootNode();
              // Adding a child to the root node
              rootNode.addChildren({ title: "", folder: true, groupType: "AND"});
            }

            break;
          case 'New Rule':
            var node = tree.getNodeByKey(this.activeNode.key);
            if (node){
              node.addChildren({
                title: "" ,
                field: "field1",
                operator: "",
                value: "",
                fieldType: "text"
              });
            }else{
              var rootNode = tree.getRootNode();
              // Adding a child to the root node
              rootNode.addChildren({
                title: "" ,
                field: "field1",
                operator: "",
                value: "",
                fieldType: "text"
              });
            }


            break;
          case 'JSON':
            this.$refs.qb.toggleLang("json");
            break;
          case 'SQL Like':
            this.$refs.qb.toggleLang("sql");
            break;
          case 'Show Preview Panel':
            this.$refs.qb.togglePreview(true);
            break;
          case 'Hide Preview Panel':
            this.$refs.qb.togglePreview(false);
            break;
          case 'Copy To Clipboard':
            this.$refs.qb.copy2clipboard();
            break;
          default:
            console.warn('Unhandled button click:', title);
        }
      },

      handlePageInfo() {
        this.$refs.excelTable.$refs.pageInfo.showPanel({
          pageIndex: this.currentPage,
          rowCount: 0,
          columnCount: 0,
          columnDetails: [
            { name: "ID", type: "Integer" },
            { name: "ID2", type: "Integer" }
          ],
        });
      },

      handleDataInfo() {
        this.$refs.excelTable.$refs.dataInfo.showPanel({
          lastUpdated: '',
          rowCount: 10,
          columnCount: 0,
          fileFormat: 'CSV',
          dataSize: '10Mb',
          columnDetails: [
            { name: "ID", type: "Integer" }
          ],
          accessPermissions: []
        });
      },
      handleReloadData(event) {
        const buttonElement = event.currentTarget;
        buttonElement.classList.add('disabled');

        this.someAsyncAction().then(() => {
          buttonElement.classList.remove('disabled');
          alert("finished")
        });
      },
      async someAsyncAction() {
        // Simulate an async operation
        return new Promise(resolve => setTimeout(resolve, 2000)); // 2 seconds delay
      },
      handlePreviousPage() {
        if(this.currentPage === 0){
          return;
        }
        this.currentPage -= 1;
        this.$refs.ribbonWrapper.setSelectValue('Page', this.currentPage.toString())
      },
      handleNextPage() {
        if(this.currentPage === this.pageCount){
          return;
        }
        this.currentPage += 1;
        this.$refs.ribbonWrapper.setSelectValue('Page', this.currentPage.toString())
      },
      handleSheetInfo() {
        // Implement logic for Sheet Info
      },
      handlePreviousSheet() {
        // Implement logic for Previous Sheet
      },
      handleNextSheet() {
        // Implement logic for Next Sheet
      },
      handleColumnInfo() {
        this.$refs.excelTable.$refs.columnInfo.showPanel({
          columnDetails: [
            { name: "ID", type: "Integer", description: "Column ID" },
            { name: "ID2", type: "Integer", description: "Column ID"  }
          ],
        });
      },
      handleShowAllColumns() {
        this.$refs.excelTable.fields.forEach((field) => {
          field.invisible = false
        })
        this.$forceUpdate()
      },
      handleHideIrrelevant() {
        this.$refs.excelTable.fields.forEach((field) => {
          if (field.name === 'name') field.invisible = true
        })
        this.$forceUpdate()
      },
      handleHideEmpty() {
        this.$refs.excelTable.columnSuppress()
      },
      handleClearFilters() {
        for (let x in this.$refs.excelTable.fields){
          this.$refs.excelTable.clearFilter(this.$refs.excelTable.fields[x].name)
        }

      },
      handleClearSelection(){
        this.$refs.excelTable.clearAllSelected();
      },
      handleExportCSV() {
        // Implement logic for Export CSV
      },
      handleExportXLSX() {
        // Implement logic for Export XLSX
      },
      handleExportParquet() {
        // Implement logic for Export Parquet
      },
      handleExportSelection() {
        // Implement logic for Export Selection
      },
      handleCurrentBatch() {
        // Implement logic for Current Batch
      },
    },

    beforeRouteEnter(to, from, next) {
      if (managedSources[to.params.dataSource]) {
        next();
      } else {
        next({ name: 'SourceNotFound' });
      }
    },
    beforeRouteUpdate(to, from, next) {
      if (managedSources[to.params.dataSource]) {
        next();
      } else {
        next({ name: 'SourceNotFound' });
      }
    },
    components: {QueryBuilder, RibbonWrapper, VueExcelEditor, VueExcelColumn},
  }
</script>

<style>
  /* Your styles here */
</style>
