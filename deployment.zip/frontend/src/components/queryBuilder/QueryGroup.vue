<template>
  <div>
    <div id="tree"  width="100%"></div>
  </div>
</template>

<script>

  export default {
    name: 'QueryGroup',
    data() {
      return {
        fields: {
          "age": "number",
          "name": "text",
          "dateOfBirth": "date",
          // Add more fields as needed
        },
        operators: ["=", ">", "<", ">=", "<=", "!="]
      };
    },
    mounted() {
      $("#tree").fancytree({
        source: [
          {title: "Group 1", folder: true, key: "group1", data: { operation: "AND" }, children: [
              {title: "Rule 1", key: "rule1"}
            ]},
          // Other groups and rules...
        ],
        renderNode: (event, data) => {
          const node = data.node;
          if (node.isFolder()) {
            this.renderGroup(node);
          } else {
            this.renderRule(node);
          }
        },
        extensions: ["wide"],
        wide: {},
      });
    },
    methods: {
      renderGroup(node) {
        if (!$(node.span).find('.group-container').length) {
          const operation = node.data.operation;
          const $toggleGroup = $(`
          <div class="group-container">
            <button class="${operation === 'AND' ? 'selected' : ''}" data-operation="AND">AND</button>
            <button class="${operation === 'OR' ? 'selected' : ''}" data-operation="OR">OR</button>
          </div>
        `);

          $toggleGroup.on('click', 'button', function() {
            const selectedOperation = $(this).data('operation');
            node.data.operation = selectedOperation;
            $toggleGroup.find('button').removeClass('selected');
            $(this).addClass('selected');
          });

          $(node.span).append($toggleGroup);
        }
      },
      renderRule(node) {
        if (!$(node.span).find('.rule-container').length) {
          const fieldSelect = $('<select class="field-select"></select>');
          for (const field in this.fields) {
            fieldSelect.append(`<option value="${field}">${field}</option>`);
          }

          const operatorSelect = $('<select class="operator-select"></select>');
          this.operators.forEach(op => {
            operatorSelect.append(`<option value="${op}">${op}</option>`);
          });

          const valueInput = $(`<input type="${this.fields[fieldSelect.val()]}" class="value-input">`);

          fieldSelect.change(() => {
            valueInput.attr('type', this.fields[fieldSelect.val()]);
          });

          const $ruleContainer = $('<div class="rule-container"></div>')
            .append(fieldSelect, operatorSelect, valueInput);

          $(node.span).append($ruleContainer);
        }
      }
    }
  };
</script>

<style scoped>
  .rule-container, .group-container {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 5px;
  }

  .field-select, .operator-select, .value-input, .group-container button {
    padding: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }

  .group-container button {
    background-color: #f5f5f5;
    cursor: pointer;
  }

  .group-container button.selected {
    background-color: #2196F3;
    color: white;
  }

  /* Additional styling as needed */
</style>
