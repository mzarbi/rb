<template>

  <div class="split-container">
    <div class="left-panel" ref="leftPanel">
      <table id="tree" width="100%">
        <colgroup>
          <col width="30px" />
          <col width="100px" />
          <col />
          <col/>
          <col/>
        </colgroup>
        <thead>
        <tr>
          <th></th>
          <th></th>
          <th style="text-align: center">Group/Rule</th>
          <th style="text-align: center">Operator</th>
          <th style="text-align: center">Value</th>
        </tr>
        </thead>
        <tbody>
        <!-- Define a row template for all invariant markup: -->
        <tr>
          <td class="alignCenter"></td>
          <td></td>
          <td>
            <select  name="sel2" style="width:100%" class="v-input stylish-input">
              <option :value="fieldName" v-for="(field, fieldName) in fields" :key="fieldName"> {{fieldName}} </option>
            </select>
          </td>

          <td>
            <select name="sel1" id="" style="width:100%" class="v-input stylish-input">
              <option value="="> = </option>
              <option value="<"> &lt; </option>
            </select>
          </td>
          <td></td>
        </tr>
        </tbody>
      </table>
    </div>
    <div class="resizer" @mousedown="initResize"></div>
    <div class="right-panel" v-if="previewVisible">
      <div>
        <pre v-if="language"><code :class="language" v-html="formattedCode"></code></pre>
        <pre v-else><code v-html="formattedCode"></code></pre>
      </div>
    </div>
  </div>
  <v-snackbar
    v-model="snackbar"
    :timeout="timeout"
  >
    {{ text }}
  </v-snackbar>




</template>

<script>
  import hljs from 'highlight.js';

  export default {
    components: {  },
    computed: {
      displayedCode(){
        console.log('Computed property recalculated', this.triggerDisplayedCode);
        if(this.language === "json"){
          var tree = $.ui.fancytree.getTree("#tree");
          if(tree){
            var d = tree.toDict(true);
            return JSON.stringify(tree.toDict(true), null, 2);
          }
          return "";
        }else{
          return "SELECT * FROM users;";
        }
      },
      formattedCode() {
        console.log('Computed property recalculated', this.triggerDisplayedCode);
        if (this.language) {
          return hljs.highlight(this.displayedCode, { language: this.language }).value;
        }
        return hljs.highlightAuto(this.displayedCode).value;
      }
    },
    data() {
      return {
        triggerDisplayedCode: 0,
        text : 'Query Copied to clipboard',
        timeout : 2000,
        snackbar : false,
        previewVisible: false,
        code: JSON.stringify({ name: "John Doe", age: 30 }, null, 2),
        language: "json",
        folderIcon: '/images/32/source.png',  // Path relative to the public folder
        fileIcon: '/images/32/source.png',      // Path relative to the public folder
        query: {
          groups: [{ operation: 'AND', rules: [], groups: [] }]
        },
        fields: {
          field1: { type: 'text', options: [] },
          field2: { type: 'number', options: [] },
          field3: { type: 'date', options: [] },
          field33: { type: 'boolean', options: [] },
          field4: { type: 'select', options: ['Option1', 'Option2'] },
        },
        treeData: [
          {
            title: "", key: "0", folder: true, groupType: "AND",children: [
              { title: "", key: "1", field: "field4", operator: "", value: "", fieldType: "select" },
              { title: "", key: "2", folder: true, groupType: "AND",children: [
                  { title: "", key: "3", field: "field1", operator: "", value: "", fieldType: "text" },
                  { title: "", key: "4", field: "field1", operator: "", value: "", fieldType: "text" }
              ]},
              { title: "", key: "22", folder: true, groupType: "AND",children: [
                  { title: "", key: "32", field: "field1", operator: "", value: "", fieldType: "text" },
                  { title: "", key: "42", field: "field1", operator: "", value: "", fieldType: "text" }
                ]}
            ]
          }
        ],

      };
    },
    methods:{
      saveTreeData(){
        var tree = $.ui.fancytree.getTree("#tree");
        if(tree){
          var x = tree.toDict(true);
          this.addTitleToNodes(x)
          this.treeData = x;
        }
      },
      addTitleToNodes(node) {
        node.title = '';

        // Check if the node has children
        if (node.children && Array.isArray(node.children)) {
          // Recursively call this function on each child
          node.children.forEach(child => addTitleToNodes(child));
        }
      },

      reloadTreeData(){
        $("#tree").fancytree("option", "source", this.treeData);
      },
      setTreeData(treeData){
        $("#tree").fancytree("option", "source", treeData);
      },
      copy2clipboard(){
        navigator.clipboard.writeText(this.displayedCode);

        this.snackbar = true;
      },
      toggleLang(tg){
        this.language = tg;
        this.triggerDisplayedCode += 1;
      },
      togglePreview(tg){
        this.previewVisible = tg;
      },
      initResize(event) {
        this.startX = event.clientX;
        this.startWidth = this.$refs.leftPanel.offsetWidth;

        document.addEventListener('mousemove', this.doResize);
        document.addEventListener('mouseup', this.stopResize);
      },
      doResize(event) {
        const width = this.startWidth + event.clientX - this.startX;
        this.$refs.leftPanel.style.width = `${Math.max(width, 0)}px`; // Ensure a minimum width if needed
      },
      stopResize() {
        document.removeEventListener('mousemove', this.doResize);
        document.removeEventListener('mouseup', this.stopResize);
      },

      showTree(){
        var tree = $.ui.fancytree.getTree("#tree");
        var d = tree.toDict(true);
        alert(JSON.stringify(d));
      },
      createToggleButton(node) {
        const vmm = this;
        // HTML for the toggle button group
        var paddingLeft = (node.getLevel() - 1) * 30 +  165 - 100;
        let toggleHtml = `
          <div class="toggle-button-group fancytree-title" style="padding-left: ${paddingLeft}px;">
            <button class="toggle-button ${node.data.groupType === 'AND' ? 'active' : ''}" data-value="AND">AND</button>
            <button class="toggle-button ${node.data.groupType === 'OR' ? 'active' : ''}" data-value="OR">OR</button>
          </div>
        `;

        // jQuery object for the HTML
        let $toggle = $(toggleHtml);

        // Event handler for button clicks
        $toggle.find('.toggle-button').on('click', function() {
          let selectedValue = $(this).data('value');
          node.data.groupType = selectedValue;
          $toggle.find('.toggle-button').removeClass('active');
          $(this).addClass('active');
          vmm.triggerDisplayedCode += 1;
        });

        return $toggle;
      }
    },
    mounted(){
      const vmm = this;
      var CLIPBOARD = null;

      $(function() {
        $("#tree")
          .fancytree({
            checkbox: false,
            icon: false,
            titlesTabbable: true, // Add all node titles to TAB chain
            quicksearch: true, // Jump to nodes when pressing first character
            // source: SOURCE,
            source: this.treeData,
            extensions: ["edit", "dnd5", "table", "gridnav"],
            activate: function(event, data) {
              var node = data.node;
              vmm.$emit('active-node-changed', node);
            },
            dnd5: {
              preventVoidMoves: true,
              preventRecursion: true,
              autoExpandMS: 400,
              dragStart: function(node, data) {
                return true;
              },
              dragEnter: function(node, data) {
                // return ["before", "after"];
                return true;
              },
              dragDrop: function(node, data) {
                data.otherNode.moveTo(node, data.hitMode);
              },
            },
            edit: {
              triggerStart: ["f2", "shift+click", "mac+enter"],
              close: function(event, data) {
                if (data.save && data.isNew) {
                  // Quick-enter: add new nodes until we hit [enter] on an empty title
                  $("#tree").trigger("nodeCommand", {
                    cmd: "addSibling",
                  });
                }
              },
            },
            table: {
              indentation: 0,
              nodeColumnIdx: 1,
            },
            gridnav: {
              autofocusInput: false,
              handleCursorKeys: true,
            },

            createNode: function(event, data) {

              var node = data.node,
                $tdList = $(node.tr).find(">td");

              if (node.isFolder()) {
                $tdList
                  .eq(1)
                  .prop("colspan", 4)
                  .nextAll()
                  .remove();
              }
            },
            renderNode: function(event, data) {
              var node = data.node;

              if (node.folder) {
                var $titleSpan = $(node.span).find('> span.fancytree-title');
                var $toggleGroup = $titleSpan.next('.toggle-button-group');

                // Only add the toggle buttons if they don't already exist
                if ($toggleGroup.length === 0) {
                  let $toggleButtons = vmm.createToggleButton(node);
                  $titleSpan.after($toggleButtons);
                }
              }

            },

            renderColumns: function(event, data) {
              var node = data.node,
                $tdList = $(node.tr).find(">td");
              // (Index #0 is rendered by fancytree by adding the checkbox)
              // Set column #1 info from node data:
              //$tdList.eq(1).text(node.getIndexHier());
              // (Index #2 is rendered by fancytree)
              // Set column #3 info from node data:



              var fieldSelect = $tdList.eq(2).find("select");
              fieldSelect.val(node.data.field);
              const newTooltip = "Tooltip for " + fieldSelect.val(); // Replace with your actual tooltip logic
              fieldSelect.attr('title', newTooltip);

              // Event listener for field select changes
              fieldSelect.on("change", function() {
                node.data.field = $(this).val();
                updateValueInput(node.data.field);

                const newTooltip = "Tooltip for " + $(this).val(); // Replace with your actual tooltip logic
                $(this).attr('title', newTooltip);
              });

              var paddingLeft = (node.getLevel() - 1) * 20 + 10;  // Adjust 15 to your preference
              $tdList.eq(2).css("padding-left", paddingLeft + "px");

              var opSelect = $tdList.eq(3).find("select");
              opSelect.val(node.data.field);
              opSelect.on("change", function() {
                node.data.operator = opSelect.val();
                vmm.triggerDisplayedCode += 1;
              });



              // Function to update the input field based on the field type
              var updateValueInput = function(fieldKey) {
                var fieldType = vmm.fields[fieldKey]?.type || 'text'; // Default to text if not found

                switch (fieldType) {
                  case 'text':
                    $tdList.eq(4).html(`<input type="${fieldType}" class="v-input stylish-input" style="width:100%" />`);
                    $tdList.eq(4).find('input').val(node.data.value).on('change', function() {
                      node.data.value = $(this).val();
                      vmm.triggerDisplayedCode += 1;
                    });
                    break;
                  case 'number':
                    $tdList.eq(4).html('<input type="number" step="any" class="v-input stylish-input" style="width:100%" />');
                    $tdList.eq(4).find('input').val(node.data.value).on('change', function() {
                      node.data.value = $(this).val();
                      vmm.triggerDisplayedCode += 1;
                    });
                    break;

                  case 'boolean':
                    const isChecked = node.data.value === true;
                    $tdList.eq(4).html(`
                      <label class="switch">
                        <input type="checkbox" class="v-input" ${isChecked ? 'checked' : ''}>
                        <span class="slider round"></span>
                      </label>
                    `);
                    $tdList.eq(4).find('input').on('change', function() {
                      node.data.value = $(this).is(':checked');
                      vmm.triggerDisplayedCode += 1;
                    });
                    break;
                  case 'date':
                    $tdList.eq(4).html('<input type="date" class="v-input stylish-input" style="width:100%" />');
                    $tdList.eq(4).find('input').val(node.data.value).on('change', function() {
                      node.data.value = $(this).val();
                      vmm.triggerDisplayedCode += 1;
                    });
                    break;
                  case 'select':
                    var selectOptions = vmm.fields[fieldKey].options.map(option =>
                      `<option value="${option}" ${option === node.data.value ? 'selected' : ''}>${option}</option>`
                    ).join('');
                    $tdList.eq(4).html(`<select class="v-select stylish-select" style="width:100%">${selectOptions}</select>`);
                    $tdList.eq(4).find('select').on('change', function() {
                      node.data.value = $(this).val();
                      vmm.triggerDisplayedCode += 1;
                    });
                    break;
                  // ... other cases ...
                }
                vmm.triggerDisplayedCode += 1;
              }.bind(this);

              // Initial setup for the value input when the row is created
              updateValueInput(node.data.field);

            },
            modifyChild: function(event, data) {
              data.tree.info(event.type, data);
            },
          });
        const tree = $("#tree").fancytree("getTree");
        tree.expandAll();
      }.bind(this));

      console.log('Computed property recalculated', this.triggerDisplayedCode);
    }
  };
</script>
<style type="text/css">
  /* Styling the table */
  #tree {
    border-collapse: collapse;
    width: 100%;
    font-size: 14px;
    font-family: Roboto, sans-serif;
  }

  /* Styling table headers */
  #tree thead th {
    background-color: #e9ecef;
    color: #333;
    text-align: left;
    padding: 8px;
    border-bottom: 0px solid #ddd;
  }
  /* Styling table rows */
  #tree tr {
    border-bottom: 0px solid #ddd;
  }


  /* Styling table cells */
  #tree td {
    padding: 8px;
    text-align: left;
  }
  /* Styling select boxes */
  #tree select {
    padding: 6px 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    background-color: white;
  }

  /* Styling input fields */
  #tree input[type="text"],
  #tree input[type="number"],
  #tree input[type="date"] {
    padding: 6px 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
  }
  .toggle-button-group {
    display: inline-flex;
    border: 0px solid #ccc;
    border-radius: 4px;
  }

  .toggle-button {
    padding: 6px 12px;
    border: none;
    background-color: white;
    cursor: pointer;
    outline: none;
    border: 1px solid #ccc;
  }

  .toggle-button.active {
    background-color: #007bff;
    color: white;
  }

  .toggle-button:not(:last-child) {
    border-right: 1px solid #ccc;
  }

  table.fancytree-ext-table tbody tr td{
    border: 0px solid #EDEDED;
  }


  .split-container {
    display: flex;
    width: 100%;
    height: 100vh; /* Adjust height as needed */
  }

  .left-panel, .right-panel {
    flex-grow: 1;
    overflow: auto; /* For scrollable content */
    padding: 5px
  }

  .resizer {
    width: 2px; /* Adjust width of the resizer */
    background: #aaa; /* Resizer color */
    cursor: ew-resize; /* Cursor on hover */
  }
  pre {
    background-color: #f4f4f4;
    padding: 10px;
    border: 1px solid #ddd;
    overflow-x: auto;
  }

  .switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
  }

  /* Hide default HTML checkbox */
  .switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  /* The slider */
  .slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    -webkit-transition: .4s;
    transition: .4s;
  }

  .slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    -webkit-transition: .4s;
    transition: .4s;
  }

  input:checked + .slider {
    background-color: #2196F3;
  }

  input:focus + .slider {
    box-shadow: 0 0 1px #2196F3;
  }

  input:checked + .slider:before {
    -webkit-transform: translateX(26px);
    -ms-transform: translateX(26px);
    transform: translateX(26px);
  }

  /* Rounded sliders */
  .slider.round {
    border-radius: 34px;
  }

  .slider.round:before {
    border-radius: 50%;
  }

  .stylish-input {
    padding: 8px !important;
    border: 1px solid #ccc !important;
    border-radius: 4px !important;
    box-sizing: border-box !important;
    transition: border-color 0.3s !important;
  }

  .stylish-input:focus {
    border-color: #88aadd !important;
    outline: none !important;
  }

  .stylish-select {
    padding: 8px !important;
    border: 1px solid #ccc !important;
    border-radius: 4px !important;
    background-color: white !important;
    box-sizing: border-box !important;
    transition: border-color 0.3s !important;
  }

  .stylish-select:focus {
    border-color: #88aadd !important;
    outline: none !important;
  }
  table.fancytree-ext-table.fancytree-treefocus tbody tr.fancytree-active {
    outline: 1px solid #26A0DA;
  }

  .fancytree-container .fancytree-expander {
    display: none;
  }
</style>
