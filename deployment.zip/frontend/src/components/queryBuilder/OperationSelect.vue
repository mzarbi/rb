<template>
  <v-select :items="['AND', 'OR']" label="Operation" v-model="operation" />
</template>

<script>
  export default {
    props: ['value'],
    computed: {
      operation: {
        get() { return this.value; },
        set(newValue) { this.$emit('update:value', newValue); }
      }
    }
  };
</script>
