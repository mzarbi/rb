<template>
  <div>
    <div v-for="(rule, index) in rules" :key="index">
      <!-- Rule display logic here -->
    </div>
    <v-btn @click="addNewRule">Add Rule</v-btn>
  </div>
</template>

<script>
  export default {
    props: ['rules'],
    methods: {
      addNewRule() {
        this.$emit('addRule', {/* New rule object */});
      }
    }
  };
</script>
