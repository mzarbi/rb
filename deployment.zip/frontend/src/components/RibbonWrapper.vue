<template>
  <div class="easyui-ribbon" id="ribbon1" ref="rbb">
    <div v-for="(tab, tabIndex) in ribbonStructure.tabs" :key="tabIndex" :title="tab.title">
      <template v-for="(group, groupIndex) in tab.groups" :key="groupIndex">
        <div class="ribbon-group">
          <div v-for="(toolbar, toolbarIndex) in group.toolbars" :key="toolbarIndex" class="ribbon-toolbar"
               :style="{ width: toolbar.size }">
            <div v-for="(tool, toolIndex) in toolbar.tools" :key="toolIndex">
              <div v-if="tool.type === 'button'" :class="['ribbon-button', `ribbon-button-${tool.size}`]" @click="buttonClicked($event, tool.title)">
                <img :src="tool.icon" class="ribbon-icon ribbon-normal"/>
                <span class="button-title">{{ tool.title }}</span>
              </div>
              <div v-else-if="tool.type === 'input'" class="ribbon-input ribbon-input-small">
                <img :src="tool.icon" class="ribbon-icon ribbon-normal"/>
                <span class="button-title" style="margin: 0px 6px;">
                  {{ tool.title }}:
                  <select @change="handleChange($event, tool.title)" style="margin: 0px 10px;" :ref="tool.title" v-model="selectValues[tool.title]">
                    <option v-for="option in tool.options" :value="option.value">{{ option.text }}</option>
                  </select>
                </span>
              </div>
              <div v-else-if="tool.type === 'checkbox'" class="ribbon-input ribbon-input-small">
                <span class="button-title" style="display: flex; align-items: center; margin: 0px 6px;">
                  <input @change="handleChange($event, tool.title)" type="checkbox" id="horns" name="horns" style="margin-right: 4px; vertical-align: middle;" />
                  {{ tool.title }}
                </span>
              </div>
              <div v-else-if="tool.type === 'slot'">
                <slot :name="tool.slotName"></slot>
              </div>
            </div>
          </div>
          <div class="ribbon-group-title">{{ group.title }}</div>
        </div>
        <div class="ribbon-group-sep"></div>
      </template>

    </div>
  </div>
</template>

<script>
  export default {
    props: {
      ribbonStructure: {
        required: true
      }
    },
    created() {
      const this_ = this;
      this.ribbonStructure.tabs.forEach(tab => {
        tab.groups.forEach(group => {
          group.toolbars.forEach(toolbar => {
            toolbar.tools.forEach(tool => {
              if (tool.type === 'input'){
                this_.selectValues[tool.title] = '';
              }
            });
          });
        });
      });
    },
    data() {
      return {
        selectValues: {}
      }
    },
    methods: {
      setSelectValue(title, value) {
        this.selectValues[title] = value
      },
      buttonClicked(event, title){
        this.$emit("buttonClicked", event, title)
      },
      handleChange(event, title) {
        alert(title)
        this.$emit('inputChanged', {
          title: title,
          value: event.target.type === 'checkbox' ? event.target.checked : event.target.value
        });
      },
    },
    mounted() {
      const vm = this;
      var ribbon = $('#ribbon1').ribbon({});
      // Attach a click event listener to the tab items
      $('.tabs li').on('click', function() {
        var selectedTabIndex = $(this).index();
        var selectedTabTitle = $(this).find('.tabs-title').text();
        vm.$emit('tab-changed', selectedTabTitle);
      });
    },
    // ... other component options ...
  };
</script>

<style scoped>
  .ribbon-button.disabled,
  .ribbon-button.disabled * { /* Disable pointer events on all child elements */
    pointer-events: none;
    opacity: 0.6; /* Visual feedback for disabled state */
  }
  .easyui-ribbon .ribbon-group .ribbon-toolbar .ribbon-button:active {
    background-color: #e0e0e0;
    border: 1px solid #a6aabf;
  }
</style>
