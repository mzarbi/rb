// Composables
import { createRouter, createWebHistory } from 'vue-router'

function isStandaloneMode() {
  return window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
}

// Set the base URL for the router
const baseUrl = isStandaloneMode() ? '/' : (window.appBranch + '/');

const routes = [
  {
    path: '/',
    component: () => import('@/layouts/default/Default.vue'),
    children: [
      {
        path: '',
        name: 'Home',
        component: () => import('@/views/Home.vue'),
      },
      {
        path: 'notifications',
        name: 'Notification',
        component: () => import('@/views/NotificationPage.vue'),
      },
      {
        path: 'sources',
        props: true,
        name: 'SourceNotFound',
        component: () => import('@/views/SourceNotFoundPage.vue'), // Create a SourcesPage.vue or adjust as needed
      },
      {
        path: 'sources/:dataSource',
        props: true,
        name: 'DataPage',
        component: () => import('@/views/DataPage.vue'), // Create a SourcesPage.vue or adjust as needed
      },
    ],
  },
]

const router = createRouter({
  history: createWebHistory(baseUrl),
  routes,
})

export default router;
