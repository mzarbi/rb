import sys

import click
import win32com.client

import win32com.client
import yaml
import os
import datetime


class TaskScheduler:
    def __init__(self, tasks_path):
        self.tasks_path = tasks_path
        self.scheduler = win32com.client.Dispatch('Schedule.Service')
        self.scheduler.Connect()

    @staticmethod
    def load_tasks_from_yaml(yaml_file):
        if not os.path.exists(yaml_file):
            raise FileNotFoundError(f"YAML file {yaml_file} not found.")

        with open(yaml_file, 'r') as file:
            return yaml.safe_load(file)['tasks']

    @staticmethod
    def create_daily_trigger(task_def, trigger_config):
        trigger = task_def.Triggers.Create(2)  # 2 is for DAILY trigger

        # Set the start time to five minutes from now
        start_time = (datetime.datetime.now() + datetime.timedelta(minutes=1)).replace(second=0,
                                                                                       microsecond=0).isoformat()
        trigger.StartBoundary = start_time
        trigger.Enabled = True

        if 'end_date' in trigger_config:
            trigger.EndBoundary = trigger_config['end_date']

    def register_task(self, task_info):
        task_name = task_info['name']
        root_folder = self.scheduler.GetFolder("\\")

        # Remove the task if it already exists
        try:
            root_folder.DeleteTask(task_name, 0)
        except Exception:
            print(f"Task {task_name} does not exist. Creating new task.")

        # Create the task
        task_def = self.scheduler.NewTask(0)

        # Create the daily trigger
        self.create_daily_trigger(task_def, task_info.get('trigger', {}))

        # Set up action
        python_exe = sys.executable

        # Set up action to run Python script
        action = task_def.Actions.Create(0)  # 0 is for EXEC action
        action.Path = python_exe
        action.Arguments = os.path.join(self.tasks_path, task_info['action']['script_path'])
        action.WorkingDirectory = self.tasks_path

        # Task configuration
        settings = task_def.Settings
        settings.Enabled = True
        settings.StartWhenAvailable = True
        settings.DisallowStartIfOnBatteries = False
        settings.StopIfGoingOnBatteries = False
        settings.RunOnlyIfNetworkAvailable = False
        settings.ExecutionTimeLimit = "PT0S"

        # Register the task
        root_folder.RegisterTaskDefinition(task_name, task_def, 6, '', '', 3)

    def register_tasks_from_yaml(self, yaml_file=None):
        if not yaml_file:
            path = os.path.join(self.tasks_path, ".tasks")
        else:
            path = yaml_file
        tasks = self.load_tasks_from_yaml(path)
        for task in tasks:
            self.register_task(task)


@click.group()
def cli():
    """Task Scheduler CLI"""
    pass


@cli.command()
@click.option('--filter', 'filter_string', default='', help='Filter tasks by name')
def list(filter_string):
    """List all registered tasks with optional filter"""
    scheduler = win32com.client.Dispatch('Schedule.Service')
    scheduler.Connect()
    root_folder = scheduler.GetFolder("\\")

    print("Registered Tasks:")
    for task in root_folder.GetTasks(0):
        if filter_string and filter_string.lower() not in task.Name.lower():
            continue

        task_state = task.State
        state_description = {
            0: 'Unknown',
            1: 'Disabled',
            2: 'Queued',
            3: 'Ready',
            4: 'Running'
        }.get(task_state, 'Unknown')

        print(f"Task Name: {task.Name}, Status: {state_description}")


@cli.command()
@click.argument('task_name')
def unregister(task_name):
    """Unregister a task"""
    scheduler = win32com.client.Dispatch('Schedule.Service')
    scheduler.Connect()
    root_folder = scheduler.GetFolder("\\")

    try:
        root_folder.DeleteTask(task_name, 0)
        print(f"Task '{task_name}' successfully unregistered.")
    except Exception as e:
        print(f"Error: Could not unregister task '{task_name}'. {e}")


@cli.command()
def register():
    """Unregister a task"""
    scheduler = TaskScheduler()
    scheduler.register_tasks_from_yaml(r'tasks.yaml')


if __name__ == '__main__':
    cli()
