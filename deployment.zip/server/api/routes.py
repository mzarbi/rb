import os

from . import api
from ..utils.file_routes import create_route_for_json_file


@api.route('/')
def index():
    return "Hello from Blueprint One!"


create_route_for_json_file(
    api,
    os.path.join(os.environ["NOTIFICATIONS_PATH"], "notifications.json"),
    '/notifications'
)
