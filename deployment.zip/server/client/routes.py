import os
from . import client
from flask import send_from_directory, current_app, g, render_template


@client.route('/', defaults={'path': ''}, methods=['GET'])
@client.route('/<path:path>', methods=['GET'])
def serve_vue_app(path):
    if path != "" and os.path.exists(os.path.join(current_app.static_folder, path)):
        return send_from_directory(current_app.static_folder, path)
    else:
        return render_template(
            'index.html',
            user_id=g.user_id,
            user_name=g.user_name,
            user_email=g.user_email,
            app_host=os.environ["APP_ROOT"],
            app_branch=os.environ["APP_BRANCH"]
        )