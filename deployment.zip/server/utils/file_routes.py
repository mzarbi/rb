import json
import os

from filelock import Timeout, FileLock
from flask import abort, jsonify


def create_route_for_json_file(blueprint, json_file_path, endpoint):
    @blueprint.route(endpoint)
    def generic_json_route():
        lock = FileLock(f"{json_file_path}.lock", timeout=10)

        try:
            with lock:
                if not os.path.exists(json_file_path):
                    abort(404, description="JSON file not found")

                with open(json_file_path, 'r') as file:
                    data = json.load(file)
                    return jsonify(data)

        except Timeout:
            abort(503, description="The request timed out while waiting for the file lock.")
        except json.JSONDecodeError:
            abort(500, description="JSON file is not properly formatted.")
        except Exception as e:
            abort(500, description=str(e))