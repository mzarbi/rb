#### DO NOT REMOVE THIS SECTION ####
import os
import time

time.sleep(1)
from dotenv import load_dotenv

load_dotenv()
#### DO NOT REMOVE THIS SECTION ####

import json
import os
from filelock import FileLock


class NotificationManager:
    def __init__(self, filepath):
        self.filepath = filepath
        self.notifications = []
        self.lock = FileLock(f"{filepath}.lock")

    def __enter__(self):
        self.lock.acquire(timeout=10)
        if os.path.exists(self.filepath):
            with open(self.filepath, 'r') as file:
                self.notifications = json.load(file)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        with open(self.filepath, 'w') as file:
            json.dump(self.notifications, file, indent=4)
        self.lock.release()

    def add_notification(self, title, text, extras=None):
        notification = {
            "id": len(self.notifications) + 1,
            "title": title,
            "text": text,
            "extras": extras if extras else {}
        }
        self.notifications.append(notification)

    def list_notifications(self):
        return self.notifications


# Example usage
with NotificationManager(os.path.join(os.environ["NOTIFICATIONS_PATH"], 'notifications.json')) as nm:
    for i in range(100):
        nm.add_notification("New Update", "Update your app to the latest version.", {"version": "1.2.3"})
        nm.add_notification("Reminder", "Don't forget the meeting at 10 AM.")
    for notification in nm.list_notifications():
        print(notification)
