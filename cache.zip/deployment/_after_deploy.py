import importlib.util
import inspect
import os
import sys

from dotenv import load_dotenv

app_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(dotenv_path=os.path.join(app_path, ".env"))


def import_class_from_path(class_name, module_path):
    spec = importlib.util.spec_from_file_location("module.name", module_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules["module.name"] = module
    spec.loader.exec_module(module)
    return getattr(module, class_name)


def create_env_file(env_dict, filename=".env"):
    with open(filename, 'w') as file:
        for key, value in env_dict.items():
            file.write(f"{key}={value}\n")


def main():
    class_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "manage_tasks.py")
    TaskScheduler = import_class_from_path("TaskScheduler", class_path)

    scheduled_tasks_path = os.environ["SCHEDULED_TASKS_PATH"]
    scheduler = TaskScheduler(scheduled_tasks_path)

    config_class = configure_env()
    config_class().init_env()
    env_data = create_env_from_config(config_class)
    create_env_file(env_data, os.path.join(scheduled_tasks_path, ".env"))
    # scheduler.register_tasks_from_yaml()


def create_env_from_config(class_obj):
    # Collect attributes from the class and its base classes
    attributes = {}
    for cls in [class_obj] + list(class_obj.__bases__):
        attributes.update({
            key: value for key, value in inspect.getmembers(cls)
            if key.isupper() and not inspect.isroutine(value)
        })
    return attributes


def configure_env():
    env = os.environ.get('FLASK_ENV', 'development')
    if env == 'development':
        from config import DevelopmentConfig
        return DevelopmentConfig
    elif env == 'wde':
        from config import WDEConfig
        return WDEConfig
    elif env == 'staging':
        from config import StagingConfig
        return StagingConfig
    elif env == 'production':
        from config import ProductionConfig
        return ProductionConfig
    else:
        raise ValueError(f'Invalid environment name "{env}"')


if __name__ == '__main__':
    main()
