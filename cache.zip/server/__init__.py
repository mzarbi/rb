import inspect
import os

from flasgger import Swagger
from flask import Flask, g
from flask_cors import CORS


def create_app():
    app = Flask(__name__)

    configure_app(app)
    app.template_folder = os.path.join(os.getcwd(), 'frontend', 'dist')
    app.static_folder = os.path.join(os.getcwd(), 'frontend', 'dist')
    app.static_url_path = app.config["APP_BRANCH"]

    @app.before_request
    def load_user():
        g.user_id = "e63551"
        g.user_email = "medzied.arbi@bnp.com"
        g.user_name = "Mohamed Zied El Arbi"

    CORS(app, resources={r'/*': {'origins': '*'}})

    Swagger(app)

    # Register blueprints
    from .api import api
    app.register_blueprint(api, url_prefix=app.config['APP_BRANCH'] + '/api')

    from .client import client
    app.register_blueprint(client, url_prefix=app.config['APP_BRANCH'] + '/')

    return app


def configure_app(app):
    env = os.environ.get('FLASK_ENV', 'development')
    if env == 'development':
        from config import DevelopmentConfig
        cls = DevelopmentConfig
    elif env == 'wde':
        from config import WDEConfig
        cls = WDEConfig
    elif env == 'staging':
        from config import StagingConfig
        cls = StagingConfig
    elif env == 'production':
        from config import ProductionConfig
        cls = ProductionConfig
    else:
        raise ValueError(f'Invalid environment name "{env}"')

    app.config.from_object(cls)
    set_env_from_config(cls)


def set_env_from_config(class_obj):
    # Collect attributes from the class and its base classes
    for cls in [class_obj] + list(class_obj.__bases__):
        for key, value in inspect.getmembers(cls):
            if key.isupper() and not inspect.isroutine(value):
                os.environ[key] = value
