import os


class Config(object):
    def init_env(self):
        os.makedirs(self.CACHED_PROPERTIES_PATH, exist_ok=True)
        os.makedirs(self.NOTIFICATIONS_PATH, exist_ok=True)


class WDEConfig(Config):
    DEBUG = True
    HOSTNAME = "http://localhost:5000/"
    APP_BRANCH = "/app"
    APP_ROOT = HOSTNAME + APP_BRANCH[1:]
    CACHE_PATH = r"C:\Users\medzi\Desktop\QMS_PLAYGROUND\s3-bouquet-1\cache"
    CACHED_PROPERTIES_PATH = os.path.join(CACHE_PATH, "CACHED_PROPERTIES")
    NOTIFICATIONS_PATH = os.path.join(CACHE_PATH, "NOTIFICATIONS")


class DevelopmentConfig(Config):
    HOSTNAME = "http://localhost:5000/"
    APP_BRANCH = "/app"
    APP_ROOT = HOSTNAME + APP_BRANCH[1:]
    CACHE_PATH = r"C:\Users\medzi\Desktop\QMS_PLAYGROUND\s3-bouquet-1\cache"
    CACHED_PROPERTIES_PATH = os.path.join(CACHE_PATH, "CACHED_PROPERTIES")
    NOTIFICATIONS_PATH = os.path.join(CACHE_PATH, "NOTIFICATIONS")


class StagingConfig(Config):
    HOSTNAME = "http://localhost:5000/"
    APP_BRANCH = ""
    APP_ROOT = HOSTNAME + APP_BRANCH[1:]
    CACHE_PATH = r"C:\Users\medzi\Desktop\QMS_PLAYGROUND\s3-bouquet-1\cache"
    CACHED_PROPERTIES_PATH = os.path.join(CACHE_PATH, "CACHED_PROPERTIES")
    NOTIFICATIONS_PATH = os.path.join(CACHE_PATH, "NOTIFICATIONS")


class ProductionConfig(Config):
    HOSTNAME = "http://localhost:5000/"
    APP_BRANCH = ""
    APP_ROOT = HOSTNAME + APP_BRANCH[1:]
    CACHE_PATH = r"C:\Users\medzi\Desktop\QMS_PLAYGROUND\s3-bouquet-1\cache"
    CACHED_PROPERTIES_PATH = os.path.join(CACHE_PATH, "CACHED_PROPERTIES")
    NOTIFICATIONS_PATH = os.path.join(CACHE_PATH, "NOTIFICATIONS")
