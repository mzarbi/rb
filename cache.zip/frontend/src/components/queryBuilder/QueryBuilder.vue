<template>
  <advanced-query-builder :config="config"
                          v-model="currentQuery"
  ></advanced-query-builder>

  <div>{{currentQuery}}</div>
</template>

<script>
  import "vue3-advanced-query-builder/dist/styles.css";
  export default {
    name: "QueryBuilder",
    data() {
      return {
        currentQuery: {},
        config: {
          levelOperators: [
            {
              name: 'and',
              identifier: 'AND'
            },
          ],
          ruleOperators: [
            {
              name: 'contains',
              identifier: 'contain',
              hasInput: false, // if ruleOperator is a Boolean as 'isEmpty'
            },
          ],
          rules: [
            // Your rules here
          ]
        }
      };
    },
    mounted() {
      // Your mounted logic here
    }
  }
</script>

