<template>
  <div id="ribbon2" class="easyui-ribbon" >
    <div title="Data">
      <div class="ribbon-group">
        <div class="ribbon-toolbar" style="width:70px">
          <div class="ribbon-button ribbon-button-large">
            <img class="ribbon-icon ribbon-normal" src="/images/32/refresh.png" />
            <span class="button-title">Reload</span>
          </div>
        </div>

        <div class="ribbon-toolbar">
          <div class="ribbon-input ribbon-input-small">
            <img class="ribbon-icon ribbon-normal" src="/images/16/copy.png" />
            <span class="button-title">
              Batch
              <select name="pets">
                <option value="dog">Dog</option>
                <option value="cat">Cat</option>
                <option value="hamster">Hamster</option>
                <option value="parrot">Parrot</option>
                <option value="spider">Spider</option>
                <option value="goldfish">Goldfish</option>
              </select>
            </span>

          </div>
          <div class="ribbon-button ribbon-button-small">
            <span class="button-title">Next</span>
            <img class="ribbon-icon ribbon-normal" src="/images/16/copy.png" />
          </div>
          <div class="ribbon-button ribbon-button-small">
            <span class="button-title">Previous</span>
            <img class="ribbon-icon ribbon-normal" src="/images/16/copy.png" />
          </div>
        </div>
        <div class="ribbon-group-title">Navigation</div>
      </div>

      <div class="ribbon-group-sep"></div>
      <div class="ribbon-group">
        <div class="ribbon-toolbar">
          <div class="ribbon-button ribbon-button-large">
            <img class="ribbon-icon ribbon-normal" src="/images/32/paste.png" />
            <span class="button-title">Paste</span>
          </div>
          <div class="ribbon-button ribbon-button-large">
            <img class="ribbon-icon ribbon-normal" src="https://via.placeholder.com/30" />
            <span class="button-title">Copy</span>
          </div>
          <div class="ribbon-button ribbon-button-large">
            <img class="ribbon-icon ribbon-normal" src="https://via.placeholder.com/30" />
            <span class="button-title">Cut</span>
          </div>
        </div>
        <div class="ribbon-toolbar">
          <div class="ribbon-button ribbon-button-small">
            <span class="button-title">Cut</span>
            <img class="ribbon-icon ribbon-normal" src="/images/16/copy.png" />
          </div>
          <div class="ribbon-button ribbon-button-small">
            <span class="button-title">Copy</span>
            <img class="ribbon-icon ribbon-normal" src="/images/16/copy.png" />
          </div>
          <div class="ribbon-button ribbon-button-small">
            <span class="button-title">Format</span>
            <img class="ribbon-icon ribbon-normal" src="/images/16/copy.png" />
          </div>
        </div>
        <div class="ribbon-group-title">Clipboard</div>
      </div>
      <div class="ribbon-group-sep"></div>
      <div class="ribbon-group">
        <div class="ribbon-toolbar" style="width:200px"></div>
        <div class="ribbon-group-title">other title</div>
      </div>
      <div class="ribbon-group-sep"></div>
    </div>
    <div title="Visualization"></div>
    <div title="Exports"></div>
  </div>

  <div class="easyui-ribbon" id="ribbon">
    <div v-for="(tab, tabIndex) in ribbonStructure.tabs" :key="tabIndex" :title="tab.title">
      <div v-for="(group, groupIndex) in tab.groups" :key="groupIndex" class="ribbon-group">
        <div v-for="(toolbar, toolbarIndex) in group.toolbars" :key="toolbarIndex" class="ribbon-toolbar">
          <!-- Render different types of tools -->
          <div v-for="(tool, toolIndex) in toolbar.tools" :key="toolIndex">
            <div v-if="tool.type === 'button'" :class="['ribbon-button', `ribbon-button-${tool.size}`]">
              <img :src="tool.icon" class="ribbon-icon ribbon-normal" />
              <span class="button-title">{{ tool.title }}</span>
            </div>
            <div v-else-if="tool.type === 'input'" class="ribbon-input ribbon-input-small">
              <img :src="tool.icon" class="ribbon-icon ribbon-normal" />
              <span class="button-title">
                {{ tool.title }}
                <select>
                  <option v-for="option in tool.options" :value="option.value">{{ option.text }}</option>
                </select>
              </span>
            </div>
            <div v-else-if="tool.type === 'slot'" >
              <slot :name="tool.slotName"></slot>
            </div>
          </div>
        </div>
        <div class="ribbon-group-title">{{ group.title }}</div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    data(){
      return {
        ribbonStructure: {
          tabs: [
            {
              title: "Data",
              groups: [
                {
                  title: "Navigation",
                  toolbars: [
                    {
                      tools: [
                        {
                          type: "button",
                          title: "Reload",
                          icon: "/images/32/refresh.png",
                          size: "large"
                        },
                        // More tools...
                      ]
                    },
                    {
                      tools: [
                        {
                          type: "input",
                          title: "Batch",
                          icon: "/images/16/copy.png",
                          options: [
                            { value: "dog", text: "Dog" },
                            { value: "cat", text: "Cat" },
                            // More options...
                          ]
                        },
                        {
                          type: "button",
                          title: "Paste",
                          icon: "/images/32/refresh.png",
                          size: "small"
                        },
                        {
                          type: "button",
                          title: "Format",
                          icon: "/images/32/refresh.png",
                          size: "small"
                        },
                        // More tools...
                      ]
                    },
                  ]
                },
                // More groups...
              ]
            },
            // More tabs...
          ]
        }
      }
    },
    mounted() {
      $('#ribbon').ribbon({
      });
    },
    // ... other component options ...
  };
</script>

<style scoped>

</style>
