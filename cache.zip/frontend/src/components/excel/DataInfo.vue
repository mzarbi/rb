<template>
  <div id="panelModal" v-show="show" class="panel-modal" @click="clickOutside" @keydown.exact.esc="hidePanel">
    <div ref="panelSetting" class="panel-body">
      <div class="panel-title">
        <span v-html="localizedLabel.dataInfo + ' ('+ formattedLastUpdated + ')'" />
      </div>
      <div class="panel-content">
        <div class="metadata-container">
          <div class="metadata-item">
            <label>Row Count:</label>
            <span>{{ metadata.rowCount }}</span>
          </div>
          <div class="metadata-item">
            <label>Column Count:</label>
            <span>{{ metadata.columnCount }}</span>
          </div>
          <div class="metadata-item">
            <label>File Format:</label>
            <span>{{ metadata.fileFormat }}</span>
          </div>
          <div class="metadata-item">
            <label>Data Size:</label>
            <span>{{ metadata.dataSize }}</span>
          </div>
          <div class="metadata-table">
            <label>Column Details:</label>
            <table>
              <thead>
              <tr>
                <th>Column Name</th>
                <th>Data Type</th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="(detail, index) in metadata.columnDetails" :key="index">
                <td>{{ detail.name }}</td>
                <td>{{ detail.type }}</td>
              </tr>
              </tbody>
            </table>
          </div>
          <div class="metadata-table">
            <label>Access Permissions:</label>
            <table>
              <thead>
              <tr>
                <th>Name</th>
                <th>ID</th>
              </tr>
              </thead>
              <tbody>
              <tr v-for="(permission, index) in metadata.accessPermissions" :key="index">
                <td>{{ permission.name }}</td>
                <td>{{ permission.id }}</td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <div class="panel-footer">
        <button ref="button" class="panel-button" @click="hidePanel">
          <span v-html="localizedLabel.back" />
        </button>
      </div>
    </div>
  </div>
</template>


<script>
  import draggable from 'vuedraggable/src/vuedraggable'
  import moment from 'moment';

  export default {
    components: {
      'draggable': draggable
    },
    props: {
      modelValue: Array,

      localizedLabel: {
        type: Object,
        default () {
          return {
            tableSetting: 'Data Info',
            exportExcel: 'Export Excel',
            importExcel: 'Import Excel',
            back: 'Back',
            reset: 'Default'
          }
        }
      }
    },
    data () {
      return {
        show: false,
        processing: false,
        metadata: {
          lastUpdated: '',
          rowCount: 0,
          columnCount: 0,
          fileFormat: 'CSV',
          dataSize: '10Mb',
          columnDetails: [
            {
              name: "ID",
              type: "Integer"
            }
          ],
          accessPermissions: []
        },
      }
    },
    computed: {
      formattedLastUpdated() {
        return moment(this.metadata.lastUpdated).fromNow();
      }
    },
    methods: {

      clickOutside (e) {
        if (e.target.id === 'panelModal') this.hidePanel()
      },
      columnLabelClick (e, item) {
        item.invisible = !item.invisible
        setTimeout(this.$parent.calStickyLeft)
      },
      freezePanelSizeAfterShown () {
        const target = this.$refs.panelList
        const rect = target.getBoundingClientRect()
        target.setAttribute('style', `width:${rect.width}px; height:${rect.height}px;`)
      },
      removePanelSizeAfterHide () {
        const target = this.$refs.panelList
        target.removeAttribute('style')
      },
      showPanel (metadata) {
        this.metadata = metadata;
        this.show = true
        setTimeout(() => (this.$refs.button.focus()))
        setTimeout(() => this.freezePanelSizeAfterShown())
      },
      hidePanel () {
        this.show = false
        this.removePanelSizeAfterHide()
      }
    }
  }
</script>

<style scoped>
  /* Adjusted styles for a cleaner look */
  .metadata-container {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 1rem;
  }
  .metadata-item {
    display: flex;
    flex-direction: column;
  }
  label {
    font-weight: bold;
    margin-bottom: 0.5rem;
  }
  .metadata-table {
    grid-column: 1 / -1;
  }
  table {
    width: 100%;
    border-collapse: collapse;
  }
  th, td {
    border: 1px solid #ddd;
    padding: 0.5rem;
    text-align: left;
  }
  th {
    background-color: #f5f5f5;
  }
  /* Rest of your styles */
  .metadata-section {
    margin-bottom: 1rem;
  }

  .metadata-item {
    margin-bottom: 0.5rem;
  }
  input:focus, button:focus {
    outline: none !important;
    box-shadow: inset 0 -1px 0 #ddd !important;
  }

  .panel-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    overflow: hidden;
    background-color: #0007;
    z-index: 999;
    font-weight: 400;
    font-size: 1rem;
    text-shadow: none;
  }

  .panel-body {
    background-color: white;
    position: fixed;
    border-radius: 5px;
    padding: 0;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 28rem;
    max-width: 75vh;
    height: fit-content;
    max-height: 80vh;
    display: flex;
    flex-direction: column;
  }

  .panel-title {
    padding: 1rem;
    display: flex;
    color: dimgray;
    font-size: 1.25rem;
    line-height: 1.5rem;
    align-items: center;
    justify-content: flex-start;
    border-bottom: 1px solid lightgray;
  }

  div.panel-title span, button.panel-button span {
    margin-left: 6px;
  }

  .panel-content {
    padding: 1rem;
    text-align: left;
    overflow-y: scroll;
  }

  .panel-content .panel-button {
    width: 48%;
    background-color: #17a2b8;
  }

  .panel-action {
    display: inline-block;
    margin-bottom: 0.5rem;
    width: 100%;
    position: relative;
    white-space: nowrap;
  }

  .panel-footer {
    display: flex;
    padding: 1rem;
    align-items: center;
    justify-content: flex-end;
    border-top: 1px solid lightgray;
  }

  .panel-button {
    width: 120px;
    font-size: 0.88rem;
    border-radius: 5px;
    border: 0;
    background-color: #007bff;
    margin-left: 10px;
    color: white;
    padding: 0.6rem;
    cursor: pointer;
  }

  .float-left {
    float: left !important;
  }

  .float-right {
    float: right !important;
  }

  .panel-list {
    overflow-y: scroll;
    max-height: 20rem;
    border: 1px solid #ced4da;
    border-radius: 0.25rem;
    display: flex;
    flex-direction: column;
  }
  .panel-checkbox {
    vertical-align: 2px;
  }
  .panel-list span {
    margin-left: 10px;
    color: gray;
  }
  .panel-list-item {
    padding: 10px 10px;
    font-size: 0.88rem;
    cursor: pointer;
  }
  .panel-list-item:hover {
    background-color: lightskyblue;
  }
  .panel-list-item:not(:last-child) {
    border-bottom: 1px solid lightgray;
  }

  .fa-spin {
    -webkit-animation: fa-spin 2s infinite linear;
    animation: fa-spin 2s infinite linear;
  }
  .svg-inline--fa.fa-w-14 {
    width: 0.875em;
  }
  .svg-inline--fa.fa-w-16 {
    width: 1em;
  }
  .svg-inline--fa.fa-fw {
    width: 1.25em;
  }
  .svg-inline--fa {
    display: inline-block;
    font-size: inherit;
    height: 1em;
    overflow: visible;
    vertical-align: -0.125em;
  }
  .fa-fw {
    text-align: center;
    width: 1.25em;
  }
  .fa-xs {
    font-size: 0.75em;
  }
  .fa-sm {
    font-size: 0.875em;
  }
  .fa-1x {
    font-size: 1em;
  }
  .fa-2x {
    font-size: 2em;
  }
  .fa-3x {
    font-size: 3em;
  }
  .no-margin {
    margin: 0 !important;
  }
</style>

