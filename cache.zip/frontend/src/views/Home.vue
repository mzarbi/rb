<template>
  <Ribbon></Ribbon>
  <RibbonWrapper :ribbon-structure="ribbonStructure"></RibbonWrapper>
  <v-card
    max-width="1000"
    class="mx-auto"
    style="margin: 1rem">


    <v-layout>
      <v-main>
        <v-container fluid>
          <v-card
            border
            class="mb-2"
            density="compact"
            prepend-avatar="https://randomuser.me/api/portraits/women/10.jpg"
            subtitle="Salsa, merengue, y cumbia"
            title="AD Groups"
            variant="text"
          >

            <v-card-text>
              During my last trip to South America, I spent 2 weeks traveling through Patagonia in Chile.
            </v-card-text>

            <template v-slot:actions>
              <v-btn color="primary" variant="text">View More</v-btn>

              <v-btn color="primary" variant="text">See in Map</v-btn>
            </template>
          </v-card>

          <v-card
            border
            density="comfortable"
            prepend-avatar="https://randomuser.me/api/portraits/women/17.jpg"
            subtitle="Salsa, merengue, y cumbia"
            title="Florida"
            variant="text"
          >

            <v-card-text>
              During my last trip to Florida, I spent 2 weeks traveling through the Everglades.
            </v-card-text>

            <template v-slot:actions>
              <v-btn color="primary" variant="text">View More</v-btn>

              <v-btn color="primary" variant="text">See in Map</v-btn>
            </template>
          </v-card>
        </v-container>
      </v-main>
    </v-layout>
  </v-card>

</template>

<script>
  import Ribbon from "@/components/Ribbon";
  import RibbonWrapper from "@/components/RibbonWrapper";
  export default {
    components: {RibbonWrapper, Ribbon},
    data(){
      return {
        ribbonStructure: {
          tabs: [
            {
              title: "Data",
              groups: [
                {
                  title: "Navigation",
                  toolbars: [
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "Reload",
                          icon: "/images/32/refresh.png",
                          size: "large"
                        },
                        // More tools...
                      ]
                    },
                    {
                      tools: [
                        {
                          type: "input",
                          title: "Batch",
                          icon: "/images/16/copy.png",
                          options: [
                            { value: "dog", text: "Dog" },
                            { value: "cat", text: "Cat" },
                            // More options...
                          ]
                        },
                        {
                          type: "button",
                          title: "Paste",
                          icon: "/images/32/refresh.png",
                          size: "small"
                        },
                        {
                          type: "button",
                          title: "Format",
                          icon: "/images/32/refresh.png",
                          size: "small"
                        },
                        // More tools...
                      ]
                    },
                  ]
                },

                {
                  title: "Navigation",
                  toolbars: [
                    {
                      size: "70px",
                      tools: [
                        {
                          type: "button",
                          title: "Reload",
                          icon: "/images/32/refresh.png",
                          size: "large"
                        },
                        // More tools...
                      ]
                    },
                  ]
                },
              ]
            },
            {
              title: "Export",
              groups: [
                {
                  title: "Selection",
                  toolbars: [
                    {
                      tools: [
                        {
                          icon: "/images/32/refresh.png",
                          type: "button",
                          title: "Export Selection",
                          size: "small"
                        },
                        {
                          icon: "/images/32/refresh.png",
                          type: "button",
                          title: "Current Batch",
                          size: "small"
                        }
                      ]
                    }
                  ]
                },
                {
                  title: "Export",
                  toolbars: [
                    {
                      tools: [
                        {
                          icon: "/images/32/refresh.png",
                          type: "button",
                          title: "CSV",
                          size: "large"
                        }
                      ]
                    },
                    {
                      tools: [

                        {
                          icon: "/images/32/refresh.png",
                          type: "button",
                          title: "XLSX",
                          size: "large"
                        }
                      ]
                    },
                    {
                      tools: [
                        {
                          icon: "/images/32/refresh.png",
                          type: "button",
                          title: "Parquet",
                          size: "large"
                        }
                      ]
                    }
                  ]
                },
              ]
            }
          ]
        }
      }
    }
  }
</script>
