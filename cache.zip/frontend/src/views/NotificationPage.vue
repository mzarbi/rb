<template>
  <v-card
    class="mx-auto"
    max-width="1000"
    style="margin: 1rem"
  >
    <v-list lines="one"
            density="compact">
      <v-list-item v-for="notification in notifications" :key="notification.id" @click="">
        <!-- Inline style for smaller text -->
        <v-list-item-title>
              <span style="font-size: 14px;font-weight: 500">
                {{ notification.title }}
              </span>
        </v-list-item-title>
        <v-list-item-title><span style="font-size: 12px">{{ notification.text }}</span></v-list-item-title>
        <template v-slot:prepend>
          <v-avatar
            color="brown"
            size="x-small"
          >
            <span class="text-h5">ADG</span>
          </v-avatar>
        </template>
      </v-list-item>
    </v-list>
  </v-card>
</template>

<script>

  import axios from "axios";

  export default {
    name: 'NotificationsPage',
    data() {
      return {
        notifications: []
      };
    },
    methods: {
      fetchNotifications() {
        axios.get(window.api + 'notifications')
          .then(response => {
            this.notifications = response.data;
          })
          .catch(error => {
            console.error('Error fetching notifications:', error);
          });
      },
    },
    created() {
      this.fetchNotifications(this.seenNotifications);
    }
  };

</script>

<style>
  /* Add your CSS styles here */
</style>
