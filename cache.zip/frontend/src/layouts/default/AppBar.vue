<template>
  <v-app-bar
    color="teal-darken-4"
    image="https://picsum.photos/1920/1080?random"
  >
    <template v-slot:image>
      <v-img
        gradient="to top right, rgba(19,84,122,.8), rgba(128,208,199,.8)"
      ></v-img>
    </template>

    <template v-slot:prepend>
      <v-app-bar-nav-icon></v-app-bar-nav-icon>
    </template>

    <v-app-bar-title>Title</v-app-bar-title>

    <v-spacer></v-spacer>

    <v-btn>
      <v-badge :content="unseenNotificationsCount.toString()" color="error">
        <v-icon>mdi-bell-outline</v-icon>
      </v-badge>

      <v-menu offset-y activator="parent">
        <v-list lines="one"
                density="compact">
          <v-list-item v-for="notification in notifications" :key="notification.id" @click="">
            <!-- Inline style for smaller text -->
            <v-list-item-title>
              <span style="font-size: 14px;font-weight: 500">
                {{ notification.title }}
              </span>
            </v-list-item-title>
            <v-list-item-title><span style="font-size: 12px">{{ notification.text }}</span></v-list-item-title>
            <template v-slot:prepend>
              <v-avatar
                color="brown"
                size="x-small"
              >
                <span class="text-h5">ADG</span>
              </v-avatar>
            </template>
          </v-list-item>
          <v-list-item @click="viewAllNotifications">
            <!-- Inline style for smaller text -->
            <v-list-item-title style="font-size: 14px;">View All Notifications</v-list-item-title>
            <template v-slot:prepend>
              <v-icon icon="mdi-folder"></v-icon>
            </template>
          </v-list-item>
        </v-list>
      </v-menu>
    </v-btn>



    <v-btn icon>
      <v-icon>mdi-dots-vertical</v-icon>
    </v-btn>
  </v-app-bar>
</template>

<script>
  import axios from 'axios';

  export default {
    data() {
      return {
        notifications: [],
        seenNotifications: [],
      };
    },
    computed: {
      unseenNotificationsCount() {
        return this.notifications.filter(
          notification => !this.seenNotifications.includes(notification.id)
        ).length;
      }
    },
    methods: {
      fetchNotifications() {
        axios.get(window.api + 'notifications')
          .then(response => {
            this.notifications = response.data;
          })
          .catch(error => {
            console.error('Error fetching notifications:', error);
          });
      },
      viewAllNotifications() {
        this.seenNotifications = this.notifications.map(notification => notification.id);
        localStorage.setItem('seenNotifications', JSON.stringify(this.seenNotifications));

        this.$router.push({ name: 'Notification' });
      }
    },
    created() {
      this.seenNotifications = JSON.parse(localStorage.getItem('seenNotifications')) || [];
      this.fetchNotifications(this.seenNotifications);

      console.log()
    }
  };
</script>
<style>
  .compact-list-item {
    padding-top: 4px;
    padding-bottom: 4px;
  }
</style>
